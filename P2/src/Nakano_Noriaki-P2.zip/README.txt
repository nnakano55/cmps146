README
P2 Navmesh Pathfinding

Programmers:
	Xuya Gao
	Noriaki Nakano 

Contents:
	p2_pathfinder.py -> our implementation of the bidirectional A* pathfinding 
	ucsc_banana_slug.png -> image to be used as the background
	ucsc_banana_slug.png.mesh.pickle -> mesh data of ucsc_banana_slug.png 
	README.txt -> this file 
